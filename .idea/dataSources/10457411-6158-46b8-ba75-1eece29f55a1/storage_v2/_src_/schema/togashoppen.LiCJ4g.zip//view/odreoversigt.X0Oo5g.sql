create view odreoversigt as
select `o`.`idordreLinjer` AS `idordreLinjer`,
       `k`.`idkunder`      AS `idkunder`,
       `k`.`navn`          AS `navn`,
       `f`.`farver`        AS `farver`
from ((`togashoppen`.`kunder` `k` join `togashoppen`.`ordrelinjer` `o` on ((`k`.`idkunder` = `o`.`kundeL`)))
       join `togashoppen`.`farver` `f` on ((`o`.`farveL` = `f`.`idfarver`)));

